package model;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
import persistence.Writable;

// present a credit risk system with 3 lists of Clients which is about
// all recorded customers, customers with high risks and customers with
// low risks respectively.
public class CRsystem implements Writable {
    private static double INTEREST = 0.05;
    private static int HIGHRISKSCORE = 500;
    private ArrayList<Client> cusTomers;
    private ArrayList<Client> lowRiskCustomers;
    private ArrayList<Client> removedCustomers;
    private double bankProfit;
    private String systemName;

    // EFFECTS: contructs CRsystem with a system name, one empty list of all customers
    //          and one other empty list of all customers with low risks
    public CRsystem(String name) {
        this.systemName = name;
        cusTomers = new ArrayList<Client>();
        lowRiskCustomers = new ArrayList<Client>();
        removedCustomers = new ArrayList<Client>();
    }

    //EFFECT: return each client in the customer list (those recorded in the system) in order
    public String getSystemName() {
        return systemName;
    }

    //EFFECT: return each client in the customer list (those recorded in the system) in order
    public ArrayList<Client> getCusTomers() {
        return cusTomers;
    }

    //EFFECT: return each client in the customer list (those recorded in the system) in order
    public ArrayList<Client> getLowriskCustomers() {
        return lowRiskCustomers;
    }


    // MODIFIES: this
    // EFFECTS: Add client in the customer list
    public void addClient(Client c) {
        this.cusTomers.add(c);
        this.lowRiskCustomers.add(c);

        String s = c.getName() + " " + c.getId() + " " + c.getLoan() + " " + c.getCrscore() + " " + c.getPi();


        EventLog.getInstance().logEvent(new Event("Added client: " + c + "\n Client: " + s));

    }


    // MODIFIES: this
    // EFFECT: get total loan amount of all clients
    //         get number of clients with pi = 1 and pi = 0
    //         return total profit of the bank, assume customers will default if their pi = 0
    public double totalProfit(ArrayList<Client> sumloanlist) {
 //       for (Client eachnewcustomer : sumloanlist) {
 //           sumloan += eachnewcustomer.getloan();
 //           if (eachnewcustomer.getpi() == 1) {
 //               numgood++;
 //           } else if (eachnewcustomer.getpi() == 0) {
 //               numbad++;
 //               sumbadloan += eachnewcustomer.getloan();
 //           }
 //       }
        int sumloan = 0;
        int sumbadloan = 0;
        for (Client eachnewcustomer : sumloanlist) {
            sumloan += eachnewcustomer.getLoan();
            if (eachnewcustomer.getPi() == 0) {
                sumbadloan += eachnewcustomer.getLoan();
            }
        }
        int sumloan1 = sumloan;
        this.bankProfit = (sumloan1 - sumbadloan) * (1 + INTEREST) - sumloan1;

        EventLog.getInstance().logEvent(new Event("Get Total Profit: $" + bankProfit));

        return bankProfit;
    }



    //MODIFIES: this
    //EFFECT: return client list include clients with low credit risk score
    public ArrayList<Client> highRiskCustomers(ArrayList<Client> list1) {
        ArrayList<Client> highriskcustomers = new ArrayList<>();
        for (Client c : list1) {
            if (c.getCrscore() <= HIGHRISKSCORE) {
                highriskcustomers.add(c);
                String s = c.getName() + " " + c.getId() + " " + c.getLoan() + " " + c.getCrscore() + " " + c.getPi();
                EventLog.getInstance().logEvent(new Event("Mark clients: " + c + "\nClient: " + s));
            }
        }
//        EventLog.getInstance().logEvent(new Event("Mark high risk clients: " + highriskcustomers));
        return highriskcustomers;
    }

    //EFFECT: remove clients with high risk (low credit risk score) from arraylist
    //        return the new list
    public void removeCustomers() {
//        ArrayList<String> removes = new ArrayList<String>();
        for (int i = 0; i < lowRiskCustomers.size(); i++) {
            if (lowRiskCustomers.get(i).getCrscore() <= HIGHRISKSCORE) {
                Client c = lowRiskCustomers.get(i);
                String s = c.getName() + " " + c.getId() + " " + c.getLoan() + " " + c.getCrscore() + " " + c.getPi();
                EventLog.getInstance().logEvent(new Event("Remove clients: " + c + "\nClient: " + s));
                removedCustomers.add(lowRiskCustomers.get(i));
//                removes.add(lowriskcustomers.get(i).getName());
                lowRiskCustomers.remove(i);
                i--;

            }
        }

//        EventLog.getInstance().logEvent(new Event("Removed clients: " + removedc + "\nClient Names: " + removes));
    }


    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("systemname", systemName);
        json.put("customers", customersToJson());
        json.put("lowriskcustomers", lowRiskCustomersToJson());
        return json;
    }

    // EFFECTS: returns things in this workroom as a JSON array
    private JSONArray customersToJson() {
        JSONArray jsonArray = new JSONArray();

        for (Client t : cusTomers) {
            jsonArray.put(t.toJson());
        }

        return jsonArray;
    }


    // EFFECTS: returns things in this workroom as a JSON array
    private JSONArray lowRiskCustomersToJson() {
        JSONArray jsonArray = new JSONArray();

        for (Client t : lowRiskCustomers) {
            jsonArray.put(t.toJson());
        }

        return jsonArray;
    }




}
