package model;

import org.json.JSONObject;
import persistence.Writable;

// present a client with his/her basic information:
//      client name
//      client ID
//      client's amount of loan request
//      client's personal credit risk score
//      client's personal performance indicator
public class Client implements Writable {
    private int performanceIndicator;
    private String clientName;
    private int clientID;
    private int loanRequest;
    private int creditRiskScore;

    /*
     * REQUIRES: clientName has a non-zero length
     *           client_ID has a length of 10
     *           loan_request > 0
     *           Credit_Risk_Score > 0
     *           performance_indicator = 1 or 0
     * EFFECTS: name on client is set to clientName; id on client is set
     *          to client_ID; amount is set to loan_request; crscore is set
     *          to Credit_Risk_Score; pi is set performance_indicator.
     */
    public Client(String name, int id, int amount, int crscore, int pi) {
        clientName = name;
        clientID = id;
        loanRequest = amount;
        creditRiskScore = crscore;
        performanceIndicator = pi;
    }

    public int getId() {
        return clientID;
    }

    public String getName() {
        return clientName;
    }

    public double getLoan() {
        return loanRequest;
    }

    public int getCrscore() {
        return creditRiskScore;
    }

    public int getPi() {
        return performanceIndicator;
    }

    /*
     * REQUIRES: id has a length of 10
     * MODIFIES: this
     * EFFECTS: ID updated
     */
    public int uniqueID(int num) {
        clientID += num;
        return clientID;
    }


//     MODIFIES: this
//     EFFECTS: name updated
    public String uniqueName(String nameclient) {
        clientName = nameclient;
        return clientName;
    }

    /*
     * REQUIRES: loan > 0
     * MODIFIES: this
     * EFFECTS: loan updated
     */
    public double uniqueLoan(double loannum) {
        if (loannum > 0) {
            loanRequest += loannum;
            return loanRequest;
        }
        return loanRequest;
    }

    /*
     * REQUIRES: crscore >= 0
     * MODIFIES: this
     * EFFECTS: crscore updated
     */
    public int uniqueCrscore(int scorenum) {
        if (scorenum >= 0) {
            creditRiskScore += scorenum;
            return creditRiskScore;
        }
        return creditRiskScore;
    }

    /*
     * REQUIRES: pi = 1 OR 0
     * MODIFIES: this
     * EFFECTS: pi updated
     */
    public int uniquePi(int pinum) {
        if (pinum == 1 || pinum == 0) {
            performanceIndicator += pinum;
            return performanceIndicator;
        }
        return performanceIndicator;
    }

//    public String toString() {
//        return clientName + " " + clientID + " " + loanRequest + " " + creditRiskScore+ " " + performanceIndicator;
//    }

    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("clientName", clientName);
        json.put("clientID", clientID);
        json.put("loanRequest", loanRequest);
        json.put("creditRiskScore", creditRiskScore);
        json.put("performanceIndicator", performanceIndicator);
        return json;
    }

}
