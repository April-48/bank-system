package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import model.*;
import model.Event;
import persistence.JsonReader;
import persistence.JsonWriter;

// Represent the credit risk system,
//   Allowed to add, remove, view, mark clients and get bank profits under current interest
public class SystemControllerUI {
    private JFrame crsFrame = new JFrame("Bank Credit Risk System");
    private static final int WIDTH = 600;
    private static final int HEIGHT = 800;

    private static final String JSON_STORE = "./data/banksystem.json";
    private static final String JSON_STORE_LOW_RISK = "./data/lowriskbanksystem.json";
    private CRsystem systemBank;

    private JsonWriter jsonWriter;
    private JsonReader jsonReader;
    private JsonWriter jsonWriterlow;
    private JsonReader jsonReaderlow;


    private JButton addNew = new JButton("add");
    private JButton removeClient = new JButton("remove");
    private JButton viewClient = new JButton("view");
    private JButton markClient = new JButton("mark");
    private JButton saveClient = new JButton("save");
    private JButton loadClient = new JButton("load");
    private JButton bankProfit = new JButton("profit");
    private JButton quitBank = new JButton("quit");
//    private JButton confirmButton = new JButton("Confirm");
//    private JButton cancelButton = new JButton("Cancel");

    private String nameContent;
    int idContent;
    int loanCont;
    int crScoreCont;
    int piCont;


    // EFFECTS: constructs credit risk system and runs application
    public SystemControllerUI() {
        jsonWriter = new JsonWriter(JSON_STORE);
        jsonReader = new JsonReader(JSON_STORE);

        jsonWriterlow = new JsonWriter(JSON_STORE_LOW_RISK);
        jsonReaderlow = new JsonReader(JSON_STORE_LOW_RISK);
        inIt();

        crsFrame.setSize(WIDTH, HEIGHT);
        crsFrame.setLayout(null);
        displayMenu();
        crsFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        crsFrame.setVisible(true);


    }

    // MODIFIES: this
    // EFFECTS: initialize the system
    public void inIt() {
        systemBank = new CRsystem("Bank System: ");
    }

    // MODIFIES: this
    // EFFECTS: set up the initial frame
    @SuppressWarnings({"checkstyle:MethodLength", "checkstyle:SuppressWarnings"})
    public void displayMenu() {
        JLabel title = new JLabel("Options: ");
        title.setBounds(100,50, 500,80);
        JLabel labeladdnew = new JLabel("1. add client into the system");
        labeladdnew.setBounds(30,100, 500,40);
        labeladdnew.setLabelFor(addNew);
        addNew.setBounds(450, 100, 80, 40);

        JLabel labelremoveclient = new JLabel("2. remove a client from my risk management system");
        labelremoveclient.setBounds(30,150, 500,40);
        labelremoveclient.setLabelFor(removeClient);
        removeClient.setBounds(450, 150, 80, 40);

        JLabel labelview = new JLabel("3. view client recorded in the system");
        labelview.setBounds(30,200, 500,40);
        labelview.setLabelFor(viewClient);
        viewClient.setBounds(450,200, 80,40);

        JLabel labelmark = new JLabel("4. mark and add clients with low credit risk score in a new list");
        labelmark.setBounds(30,250, 500,40);
        labelmark.setLabelFor(markClient);
        markClient.setBounds(450,250, 80,40);

        JLabel labelprofit = new JLabel("5. get bank profit");
        labelprofit.setBounds(30,300, 500,40);
        labelprofit.setLabelFor(bankProfit);
        bankProfit.setBounds(450,300, 80,40);


        JLabel labelsave = new JLabel("6. save bank system info to file");
        labelsave.setBounds(30,350, 500,40);
        labelsave.setLabelFor(saveClient);
        saveClient.setBounds(450,350, 80,40);

        JLabel labelload = new JLabel("7. load bank system info from file");
        labelload.setBounds(30,400, 500,40);
        labelload.setLabelFor(loadClient);
        loadClient.setBounds(450,400, 80,40);

        JLabel labelquit = new JLabel("8. quit");
        labelquit.setBounds(30,450, 500,40);
        labelquit.setLabelFor(quitBank);
        quitBank.setBounds(450,450, 80,40);

        JLabel image = new JLabel(); //JLabel Creation
        image.setIcon(new ImageIcon("loan.png"));
        image.setBounds(250,500, 300,300);

        crsFrame.add(title);
        crsFrame.add(labeladdnew);
        crsFrame.add(addNew);
        crsFrame.add(labelremoveclient);
        crsFrame.add(removeClient);
        crsFrame.add(labelview);
        crsFrame.add(viewClient);
        crsFrame.add(labelmark);
        crsFrame.add(markClient);
        crsFrame.add(labelprofit);
        crsFrame.add(bankProfit);
        crsFrame.add(labelsave);
        crsFrame.add(saveClient);
        crsFrame.add(labelload);
        crsFrame.add(loadClient);
        crsFrame.add(quitBank);
        crsFrame.add(labelquit);
        crsFrame.add(image);
        crsFrame.setLocationRelativeTo(null);

        doOneOperation();
        doTwoOperation();
        doThreeOperation();
    }

    // MODIFIES: this
    // EFFECTS: click the button and do certain operation
    public void doOneOperation() {
        addNew.addActionListener(new ActionListener() {
            // EFFECTS: call add method
            @Override
            public void actionPerformed(ActionEvent e) {
                setAddClient();
            }
        });
        removeClient.addActionListener(new ActionListener() {
            // EFFECTS: call remove method
            @Override
            public void actionPerformed(ActionEvent e) {
                doRemoveCustomers();
            }
        });
        viewClient.addActionListener(new ActionListener() {
            // EFFECTS: call view method
            @Override
            public void actionPerformed(ActionEvent e) {
                doGetCustomersss();
            }
        });
    }

    // MODIFIES: this
    // EFFECTS: click the button and do certain operation
    public void doTwoOperation() {
        markClient.addActionListener(new ActionListener() {
            // EFFECTS: call mark method
            @Override
            public void actionPerformed(ActionEvent e) {
                doHighriskCustomers();
            }
        });

        bankProfit.addActionListener(new ActionListener() {
            // EFFECTS: call get profit method
            @Override
            public void actionPerformed(ActionEvent e) {
                doTotalProfit();
            }
        });
        saveClient.addActionListener(new ActionListener() {
            // EFFECTS: call save method
            @Override
            public void actionPerformed(ActionEvent e) {
                saveCrSystem();
            }
        });
    }

    // MODIFIES: this
    // EFFECTS: click the button and do certain operation
    public void doThreeOperation() {
        loadClient.addActionListener(new ActionListener() {
            // EFFECTS: call load method
            @Override
            public void actionPerformed(ActionEvent e) {
                loadBankSystem();
            }
        });
        quitBank.addActionListener(new ActionListener() {
            // EFFECTS: close the window
            @Override
            public void actionPerformed(ActionEvent e) {
                doQuit();
            }
        });
    }

    // EFFECTS: Shows all events(operations) officer have done
    public void doQuit() {
        JDialog jquit = new JDialog();
        JTextArea logArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(logArea);
        JButton quit = new JButton("Quit");

        logArea.setEditable(false);
        jquit.setLayout(new GridLayout(3, 5, 30, 30));
        jquit.setSize(600, 1000);
        jquit.setName("Quit");

        EventLog events = EventLog.getInstance();
        for (Event next : events) {
            logArea.setText(logArea.getText() + next.toString() + "\n\n");
        }

        jquit.add(scrollPane);
        jquit.add(quit);
        logArea.repaint();

        jquit.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jquit.setVisible(true);

        quitOperation(quit, jquit, crsFrame);

    }

    // EFFECTS: close two windows at the same time
    public void quitOperation(JButton cl, JDialog jd, JFrame jf) {
        cl.addActionListener(new ActionListener() {
            // EFFECTS: close the window
            @Override
            public void actionPerformed(ActionEvent e) {
                jd.dispose();
                jf.dispose();
            }
        });
    }



    // MODIFIES: this
    // EFFECTS: conduct an operation of add client in the customer list
    //          click confirm button to check if the input is valid;
    //          click cancel button to quit
    @SuppressWarnings({"checkstyle:MethodLength", "checkstyle:SuppressWarnings"})
    public void setAddClient() {
        JDialog jaddclient = new JDialog();
        jaddclient.setLayout(new GridLayout(10, 30, 30, 30));
        jaddclient.setSize(600, 1000);
        jaddclient.setName("Add New Client");

        JFormattedTextField name = new JFormattedTextField();
        JLabel addcname = new JLabel("Client Name: ");
        addcname.setLabelFor(name);

        JFormattedTextField id = new JFormattedTextField();
        JLabel addcid = new JLabel("Client ID: ");
        addcid.setLabelFor(id);

        JFormattedTextField loan = new JFormattedTextField();
        JLabel addcloan = new JLabel("Loan Request: ");
        addcloan.setLabelFor(loan);

        JFormattedTextField crscore = new JFormattedTextField();
        JLabel addccrscore = new JLabel("Credit Risk Score: ");
        addccrscore.setLabelFor(crscore);

        JFormattedTextField pi = new JFormattedTextField();
        JLabel addcpi = new JLabel("Performance Indicator: ");
        addcpi.setLabelFor(pi);

        JButton confirm = new JButton("Confirm");
        JButton cancel = new JButton("Cancel");


        jaddclient.add(addcname);
        jaddclient.add(name);
        jaddclient.add(addcid);
        jaddclient.add(id);
        jaddclient.add(addcloan);
        jaddclient.add(loan);
        jaddclient.add(addccrscore);
        jaddclient.add(crscore);
        jaddclient.add(addcpi);
        jaddclient.add(pi);

        jaddclient.add(confirm);
        jaddclient.add(cancel);

        jaddclient.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jaddclient.setVisible(true);


        confirm.addActionListener(new ActionListener() {

            // MODIFIES: this
            // EFFECT: get input values, check input are valid
            @Override
            public void actionPerformed(ActionEvent e) {

                name.addActionListener(this);
                nameContent = name.getText();
                id.addActionListener(this);
                idContent = Integer.parseInt(id.getText());
                loan.addActionListener(this);
                loanCont = Integer.parseInt(loan.getText());
                crscore.addActionListener(this);
                crScoreCont = Integer.parseInt(crscore.getText());
                pi.addActionListener(this);
                piCont = Integer.parseInt(pi.getText());


                JDialog d = new JDialog();
                JButton close = new JButton("ok");
                d.add(close);
                d.setVisible(true);
                d.setLayout(new GridLayout(8, 1, 30, 30));
                d.setSize(300, 200);

                int idDigits = String.valueOf(idContent).length();
                boolean set = true;
                confirmOperation(idDigits, set, d, jaddclient, close);
            }

        });

        closeOperation(cancel, jaddclient);
    }


    // REQUIRES: length of id = 8; loan > 0; crscore >= 0; performance_indicator = 1 OR 0
    // EFFECTS: check if inputs are valid after click on check button
    public void confirmOperation(int idlen, Boolean set, JDialog d, JDialog jaddclient, JButton close) {
        if (idlen != 8) {
            confirmCheck(idlen, d, close, set, "Incorrect ID!\n");
            set = false;
        }
        if (loanCont < 0) {
            confirmCheck(loanCont, d, close, set, "Loan Amount Cannot Be Negative!\n");
            set = false;
        }
        if (crScoreCont < 0) {
            confirmCheck(loanCont, d, close, set, "Credit Risk Score Cannot Be Negative!\n");
            set = false;
        }
        if (!(piCont == 1 || piCont == 0)) {
            confirmCheck(loanCont, d, close, set, "Invalid PI! [1 for good! 0 for bad!] \n");
            set = false;
        } else if (set) {
            Client clientnew = new Client(nameContent, idContent, loanCont, crScoreCont, piCont);
            systemBank.addClient(clientnew);
            confirmCheck(loanCont, d, close, set, "New Client Add Successfully! \n");
        }
        closeOperation(close, d);
    }

    // EFFECTS: check input condition and print the output
    public Boolean confirmCheck(int a, JDialog m, JButton cl, Boolean set1, String s) {
        JLabel addresult1 = new JLabel(s);
        m.add(addresult1);
        m.add(cl);
        m.pack();
        m.setVisible(true);
        set1 = false;
        return set1;
    }

//    // EFFECTS: close two windows at the same time
//    public void closeTwoOperation(JButton cl, JDialog jd, JDialog jf) {
//        cl.addActionListener(new ActionListener() {
//            // EFFECTS: close the window
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                jd.dispose();
//                jf.dispose();
//            }
//        });
//    }

    // EFFECT: close the window after click on close button
    public void closeOperation(JButton cl, JDialog d) {
        cl.addActionListener(new ActionListener() {
            // EFFECTS: close the window
            @Override
            public void actionPerformed(ActionEvent e) {
                d.dispose();
            }
        });
    }



    // MODIFIES: this
    // EFFECTS: conduct an operation of view the list of customers with high credit risk score
    //          a new window shows up with the obtained list using remove funtion
    public void doRemoveCustomers() {
        JDialog jremoveclient = new JDialog();
        jremoveclient.setLayout(new GridLayout(10, 1, 30, 30));
        jremoveclient.setSize(600, 1000);
        jremoveclient.setName("Remove Client");
        JButton close = new JButton("ok");
        JLabel removec = new JLabel("Customers with credit risk scores > 500: ");

        jremoveclient.add(removec);
        systemBank.removeCustomers();
        for (Client eachcustomer : systemBank.getLowriskCustomers()) {
            String text = eachcustomer.getId() + " " + eachcustomer.getCrscore();
            JLabel texteach = new JLabel(text);
            jremoveclient.add(texteach);
        }

        jremoveclient.add(close);
        jremoveclient.setVisible(true);

        closeOperation(close, jremoveclient);

    }

    // MODIFIES: this
    // EFFECTS: conduct an operation of view the entire customer list
    //          open a new window to show the obtianed lists using view function
    public void doGetCustomersss() {
        JDialog jviewclient = new JDialog();
        jviewclient.setLayout(new GridLayout(2, 1, 30, 30));
        jviewclient.setSize(600, 1000);
        jviewclient.setName("Get Client");

        JTextArea viewArea = new JTextArea();
        viewArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(viewArea);

        JButton close = new JButton("ok");
        close.setBounds(280,900,40, 20);

        viewOperation(systemBank.getCusTomers(), "All recorded Customers:", viewArea);
        viewOperation(systemBank.getLowriskCustomers(), "All recorded Customers with low risks:", viewArea);

        jviewclient.add(scrollPane);
        jviewclient.add(close);
        viewArea.repaint();

        jviewclient.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jviewclient.setVisible(true);
        closeOperation(close, jviewclient);
    }

    // EFFECTS: open a new window and shows every client after click on view button
    public void viewOperation(ArrayList<Client> clients, String s, JTextArea viewArea) {
        viewArea.append("\n" + s + "\n\n");
        for (Client eachcustomer : clients) {
            String each = null;
            String eachname = eachcustomer.getName();
            int eachID = eachcustomer.getId();
            double eachloan = eachcustomer.getLoan();
            int eachscore = eachcustomer.getCrscore();
            int eachpi = eachcustomer.getPi();
            each = eachname + " " + eachID + " " + eachloan + " " + eachscore + " " + eachpi;
            viewArea.append(each + "\n");
        }

    }




    // MODIFIES: this
    // EFFECTS: conduct an operation of view the list of customers with low credit risk score
    public void doHighriskCustomers() {
        JDialog jmarkclient = new JDialog();
        jmarkclient.setLayout(new GridLayout(10, 1, 30, 30));
        jmarkclient.setSize(600, 1000);
        jmarkclient.setName("Mark Client");
        JButton close = new JButton("ok");
        JLabel markc = new JLabel("Customers with credit risk scores <= 500: ");

        jmarkclient.add(markc);

        for (Client eachcustomer : systemBank.highRiskCustomers(systemBank.getCusTomers())) {
            String texteach = null;
            texteach = eachcustomer.getId() + " " + eachcustomer.getCrscore();
            JLabel text = new JLabel(texteach);
            jmarkclient.add(text);
        }

        jmarkclient.add(close);
        jmarkclient.setVisible(true);

        closeOperation(close, jmarkclient);


    }

    // MODIFIES: this
    // EFFECTS: conduct an operation of getting bank's total profit
    //          open a new window and show profit
    public void doTotalProfit() {
        JDialog jprofitclient = new JDialog();
        jprofitclient.setLayout(new GridLayout(10, 1, 30, 30));
        jprofitclient.setSize(600, 1000);
        jprofitclient.setName("Bank Profit");
        JButton close = new JButton("ok");

        double num =  systemBank.totalProfit(systemBank.getCusTomers());
        String n = String.valueOf(num);
        JLabel bankprofit = new JLabel("Bank Profit is ($): " + n);
        jprofitclient.add(bankprofit);

        jprofitclient.add(bankprofit);
        jprofitclient.add(close);
        jprofitclient.setVisible(true);

        closeOperation(close, jprofitclient);
//        close.addActionListener(new ActionListener() {
//            // EFFECTS: close the window
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                jprofitclient.dispose();
//            }
//        });
    }

    // EFFECTS: saves the workroom to file
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    // open a window shows save successfully
    private void saveCrSystem() {
        JDialog jsave = new JDialog();
        jsave.setLayout(new GridLayout(10, 1, 30, 30));
        jsave.setSize(600, 1000);
        jsave.setName("Save CRstsyem");
        JButton close = new JButton("ok");

        try {
            jsonWriter.open();
            jsonWriter.write(systemBank);
            jsonWriter.close();
            JLabel saveinfo = new JLabel("Saved " + systemBank.getSystemName() + " to " + JSON_STORE);
            jsave.add(saveinfo);

        } catch (FileNotFoundException e) {
            JLabel saveinfo1 = new JLabel("Unable to write to file: " + JSON_STORE);
            jsave.add(saveinfo1);
        }

        jsave.add(close);
        jsave.setVisible(true);

        closeOperation(close, jsave);
    }

    // MODIFIES: this
    // EFFECTS: loads workroom from file
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    // open a window shows load successfully
    private void loadBankSystem() {
        JDialog jload = new JDialog();
        jload.setLayout(new GridLayout(10, 1, 30, 30));
        jload.setSize(600, 1000);
        jload.setName("Load CRstsyem");
        JButton close = new JButton("ok");

        try {
            systemBank = jsonReader.read();
            JLabel loadinfo = new JLabel("Loaded " + systemBank.getSystemName() + " from " + JSON_STORE);
            jload.add(loadinfo);
        } catch (IOException e) {
            JLabel loadinfo1 = new JLabel("Unable to read from file: " + JSON_STORE);
            jload.add(loadinfo1);
        }

        jload.add(close);
        jload.setVisible(true);

        closeOperation(close, jload);
    }



}


