package ui;

import java.io.IOException;
import java.util.Scanner;
import model.Client;
import model.CRsystem;
import persistence.JsonReader;
import persistence.JsonWriter;


import java.io.FileNotFoundException;

// Represent the credit risk system
//   Allowed to add, remove, view, mark clients and get bank profits under current interest
public class BankSystem {
    private static final String JSON_STORE = "./data/banksystem.json";
    private static final String JSON_STORE_LOW_RISK = "./data/lowriskbanksystem.json";
    private CRsystem systembank;
    private Scanner input;

    private JsonWriter jsonWriter;
    private JsonReader jsonReader;
    private JsonWriter jsonWriterlow;
    private JsonReader jsonReaderlow;


//    private ArrayList<Client> customersss = new ArrayList<Client>();
//    private ArrayList<Client> highriskcustomers = new ArrayList<Client>();
//    private ArrayList<Client> lowriskcustomers = new ArrayList<Client>();

    // EFFECTS: constructs credit risk system and runs application
    public BankSystem() throws FileNotFoundException {
        jsonWriter = new JsonWriter(JSON_STORE);
        jsonReader = new JsonReader(JSON_STORE);

        jsonWriterlow = new JsonWriter(JSON_STORE_LOW_RISK);
        jsonReaderlow = new JsonReader(JSON_STORE_LOW_RISK);
        input = new Scanner(System.in);
        runBank();

    }

    // MODIFIES: this
    // EFFECTS: processes user input
    private void runBank() {
        boolean keepGoing = true;
        String command = null;

        inIt();
        while (keepGoing) {
            displayMenu();
            command = input.next();
            command = command.toLowerCase();
            if (command.equals("q")) {
                keepGoing = false;
            } else {
                processCommand(command);
            }
        }
        System.out.println("\nCancel!");
    }

    // MODIFIES: this
    // EFFECTS: processes user command
    private void processCommand(String command) {
        if (command.equals("a")) {
            doAddClient();
        } else if (command.equals("v")) {
            doGetCustomersss();
        } else if (command.equals("m")) {
            doHighriskCustomers();
        } else if (command.equals("r")) {
            doRemoveCustomers();
        } else if (command.equals("p")) {
            doTotalProfit();
        } else if (command.equals("s")) {
            saveCrSystem();
        } else if (command.equals("l")) {
            loadBankSystem();
        } else {
            System.out.println("Selection not valid...");
        }
    }


    // EFFECTS: initialize the system and give the system a name
    private void inIt() {
        input = new Scanner(System.in);
        input.useDelimiter("\n");
        systembank = new CRsystem("Bank System: ");
    }


    // EFFECTS: displays menu of options to user
    private void displayMenu() {
        System.out.println("\nSelect From: ");
        System.out.println("\ta -> add client into the system");
        System.out.println("\tv -> view client recorded in the system");
        System.out.println("\tm -> mark and add clients with low credit risk score in a new list");
        System.out.println("\tr -> remove a client from my risk management system");
        System.out.println("\tp -> get bank profit");
        System.out.println("\ts -> save bank system info to file");
        System.out.println("\tl -> load bank system info from file");
        System.out.println("\tq -> quit");
    }

    // MODIFIES: this
    // EFFECTS: Add client name
    public String inputName() {
        System.out.println("client name: ");
        String name = input.next();
        //       client.uniqueName(name);
        return name;
    }

    // REQUEST: length of id = 8
    // MODIFIES: this
    // EFFECTS: Add client id
    public int inputID() {
        System.out.println("client ID: ");
        int id = input.nextInt();
        int numDigits = String.valueOf(id).length();

        while (!(numDigits == 8)) {
            System.out.println("Incorrect ID!\n");
            System.out.println("client ID: ");
            id = input.nextInt();
            numDigits = String.valueOf(id).length();
        }
//        client.uniqueID(id);
        return id;
    }

    // REQUEST: loan > 0
    // MODIFIES: this
    // EFFECTS: Add loan request
    public int inputLoan() {
        System.out.println("loan request: ");
        int loan = input.nextInt();
        while (loan < 0) {
            System.out.print("Loan amount Cannot Be Negative!\n");
            System.out.println("loan request: ");
            loan = input.nextInt();
        }
//        client.uniqueloan(loan);
        return loan;
    }

    // REQUEST: crscore >= 0
    // MODIFIES: this
    // EFFECTS: Add loan request
    public int inputCrscore() {
        System.out.println("Credit Risk Score: ");
        int numcrscore = input.nextInt();
        while (numcrscore < 0) {
            System.out.print("Credit Risk Score Cannot Be Negative!\n");
            System.out.println("Credit Risk Score: ");
            numcrscore = input.nextInt();
        }
//        client.uniquecrscore(numcrscore);
        return numcrscore;
    }

    // REQUEST: performance_indicator = 1 OR 0
    // MODIFIES: this
    // EFFECTS: Add performance indicator
    public int inputPI() {
        System.out.println("performance indicator: ");
        int numpi = input.nextInt();

        while (!(numpi == 1 || numpi == 0)) {
            System.out.println("1 for good");
            System.out.println("0 for bad");
            numpi = input.nextInt();
        }
//        client.uniquepi(numpi);
        return numpi;
    }

    // MODIFIES: this
    // EFFECTS: conduct an operation of add client in the customer list
    public void doAddClient() {
        System.out.println("\n" + systembank.getSystemName());
        String name = inputName();
        int id = inputID();
        int loan = inputLoan();
        int crscore = inputCrscore();
        int pi = inputPI();
        Client clientnew = new Client(name, id, loan, crscore, pi);
        //      customersss.add(client);
        systembank.addClient(clientnew);
        System.out.println("add successfully!");
    }


    // MODIFIES: this
    // EFFECTS: conduct an operation of view the entire customer list
    private void doGetCustomersss() {
        System.out.println("\nCustomers recorded in the bank system: \n");
        System.out.println("All recorded Customers:");
        for (Client eachcustomer : systembank.getCusTomers()) {
            String eachname = eachcustomer.getName();
            int eachID = eachcustomer.getId();
            double eachloan = eachcustomer.getLoan();
            int eachscore = eachcustomer.getCrscore();
            int eachpi = eachcustomer.getPi();
            System.out.println("\t" + eachname + " " + eachID + " " + eachloan + " " + eachscore + " " + eachpi);
        }

        System.out.println("All recorded Customers with low risks:");
        for (Client eachcustomer : systembank.getLowriskCustomers()) {
            String eachname = eachcustomer.getName();
            int eachID = eachcustomer.getId();
            double eachloan = eachcustomer.getLoan();
            int eachscore = eachcustomer.getCrscore();
            int eachpi = eachcustomer.getPi();
            System.out.println("\t" + eachname + " " + eachID + " " + eachloan + " " + eachscore + " " + eachpi);
        }
    }

    // MODIFIES: this
    // EFFECTS: conduct an operation of getting bank's total profit
    public void doTotalProfit() {
        double profit = systembank.totalProfit(systembank.getCusTomers());
        System.out.println("Bank Profit is: $ " + profit);
    }

    // MODIFIES: this
    // EFFECTS: conduct an operation of view the list of customers with low credit risk score
    public void doHighriskCustomers() {
        System.out.println("\nCustomers with credit risk scores <= 500: \n");
        for (Client eachcustomer : systembank.highRiskCustomers(systembank.getCusTomers())) {
            System.out.println("\t" + eachcustomer.getId() + " " + eachcustomer.getCrscore() + "\n");
        }
    }


    // MODIFIES: this
    // EFFECTS: conduct an operation of view the list of customers with high credit risk score
    public void doRemoveCustomers() {
        System.out.println("\nCustomers with credit risk scores > 500: \n");
        systembank.removeCustomers();
        for (Client eachcustomer : systembank.getCusTomers()) {
            System.out.println("\t" + eachcustomer.getId() + " " + eachcustomer.getCrscore() + "\n");
        }
    }


    // EFFECTS: saves the workroom to file
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    private void saveCrSystem() {
        try {
            jsonWriter.open();
            jsonWriter.write(systembank);
            jsonWriter.close();
            System.out.println("Saved " + systembank.getSystemName() + " to " + JSON_STORE);
        } catch (FileNotFoundException e) {
            System.out.println("Unable to write to file: " + JSON_STORE);
        }
    }

    // MODIFIES: this
    // EFFECTS: loads workroom from file
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    private void loadBankSystem() {
        try {
            systembank = jsonReader.read();
            System.out.println("Loaded " + systembank.getSystemName() + " from " + JSON_STORE);
        } catch (IOException e) {
            System.out.println("Unable to read from file: " + JSON_STORE);
        }
    }




}
