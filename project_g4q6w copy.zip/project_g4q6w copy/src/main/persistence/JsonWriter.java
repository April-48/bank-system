package persistence;

import model.CRsystem;
import org.json.JSONObject;


import java.io.*;

// Represents a writer that writes JSON representation of workroom to file
// Refer from the JsonSerializationDemo which can be found in
// https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
public class JsonWriter {
    private static final int TAB = 4;
    private PrintWriter writer;
    private String destination;

    // EFFECTS: constructs writer to write to destination file
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    public JsonWriter(String destination) {
        this.destination = destination;
    }

    // MODIFIES: this
    // EFFECTS: opens writer; throws FileNotFoundException if destination file cannot
    // be opened for writing
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    public void open() throws FileNotFoundException {
        writer = new PrintWriter(new File(destination));
    }

    // MODIFIES: this
    // EFFECTS: writes JSON representation of workroom to file
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    public void write(CRsystem crs) {
        JSONObject json = crs.toJson();
        saveToFile(json.toString(TAB));
    }

    // MODIFIES: this
    // EFFECTS: closes writer
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    public void close() {
        writer.close();
    }

    // MODIFIES: this
    // EFFECTS: writes string to file
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    private void saveToFile(String json) {
        writer.print(json);
    }
}
