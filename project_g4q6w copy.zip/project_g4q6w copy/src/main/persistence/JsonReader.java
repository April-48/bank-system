package persistence;

import model.Client;
import model.CRsystem;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

import org.json.*;

// Represents a reader that reads workroom from JSON data stored in file
// Refer from the JsonSerializationDemo which can be found in
//https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
public class JsonReader {
    private String source;

    // EFFECTS: constructs reader to read from source file
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    public JsonReader(String source) {
        this.source = source;
    }

    // EFFECTS: reads workroom from file and returns it;
    // throws IOException if an error occurs reading data from file
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    public CRsystem read() throws IOException {
        String jsonData = readFile(source);
        JSONObject jsonObject = new JSONObject(jsonData);
        return parseWorkRoom(jsonObject);
    }

    // EFFECTS: reads source file as string and returns it
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    private String readFile(String source) throws IOException {
        StringBuilder contentBuilder = new StringBuilder();

        try (Stream<String> stream = Files.lines(Paths.get(source), StandardCharsets.UTF_8)) {
            stream.forEach(s -> contentBuilder.append(s));
        }

        return contentBuilder.toString();
    }

    // EFFECTS: parses workroom from JSON object and returns it
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    private CRsystem parseWorkRoom(JSONObject jsonObject) {
        String name = jsonObject.getString("systemname");
        CRsystem crs = new CRsystem(name);
        addClients(crs, jsonObject);
        return crs;
    }


    // MODIFIES: crs
    // EFFECTS: parses clients from JSON object and adds them to crsystem
    // Refer from the JsonSerializationDemo which can be found in
    // https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    private void addClients(CRsystem crs, JSONObject jsonObject) {
        JSONArray jsonArray = jsonObject.getJSONArray("customers");
        for (Object json : jsonArray) {
            JSONObject nexClient = (JSONObject) json;
            addClient(crs, nexClient);
        }
        crs.removeCustomers();
    }

    // MODIFIES: crs
    // EFFECTS: parses clients from JSON object and adds them to crsystem
    /*private void addlowriskClients(CRsystem crs, JSONObject jsonObject) {
        JSONArray jsonArray2 = jsonObject.getJSONArray("lowriskcustomers");
        for (Object json : jsonArray2) {
            JSONObject nexClient = (JSONObject) json;
            addClient(crs, nexClient);
        }
        crs.removeCustomers();
    }*/

    // MODIFIES: crs
    // EFFECTS: parses thingy from JSON object and adds it to workroom
    private void addClient(CRsystem crs, JSONObject jsonObject) {
        String clientName = jsonObject.getString("clientName");
        int clientID = jsonObject.getInt("clientID");
        int loanRequest = jsonObject.getInt("loanRequest");
        int creditRiskScore = jsonObject.getInt("creditRiskScore");
        int performanceIndicator = jsonObject.getInt("performanceIndicator");

        Client client = new Client(clientName, clientID, loanRequest, creditRiskScore, performanceIndicator);
        crs.addClient(client);
    }

}
