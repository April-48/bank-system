package persistence;

import model.Client;
import model.CRsystem;

import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class JsonReaderTest extends JsonTest {

    @Test
    void testReaderNonExistentFile() {
        JsonReader reader = new JsonReader("./data/noSuchFile.json");
        try {
            CRsystem crs = reader.read();
            fail("IOException expected");
        } catch (IOException e) {
        }
    }

    @Test
    void testReaderEmptyCRsystem() {
        JsonReader reader = new JsonReader("./data/testReaderEmptyCRsystem.json");
        try {
            CRsystem crs = reader.read();
            assertEquals("Bank System: ", crs.getSystemName());
            assertEquals(0, crs.getCusTomers().size());
            assertEquals(0, crs.getLowriskCustomers().size());
        } catch (IOException e) {
            fail("Couldn't read from file");
        }
    }

    @Test
    void testReaderGeneralCRsystem() {
        JsonReader reader = new JsonReader("./data/testReaderGeneralCRsystem.json");
        try {
            CRsystem crs  = reader.read();

            assertEquals("Bank System: ", crs.getSystemName());
            ArrayList<Client> customers = crs.getCusTomers();
 //           assertEquals(2, customers.size());
            checkCRsystem("a", 10101010, 100, 800, 1, customers.get(0));
            checkCRsystem("b", 11111111, 100, 500, 1, customers.get(1));

            ArrayList<Client> lowriskcustomers = crs.getLowriskCustomers();
 //           assertEquals(1, lowriskcustomers.size());
            checkCRsystemLow("a", 10101010, 100, 800, 1, lowriskcustomers.get(0));
        } catch (IOException e) {
            fail("Couldn't read from file");
        }
    }
}