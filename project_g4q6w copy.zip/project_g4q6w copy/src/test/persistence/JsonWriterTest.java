package persistence;

import model.Client;
import model.CRsystem;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class JsonWriterTest extends JsonTest {
    //NOTE TO CPSC 210 STUDENTS: the strategy in designing tests for the JsonWriter is to
    //write data to a file and then use the reader to read it back in and check that we
    //read in a copy of what was written out.

    @Test
    void testWriterInvalidFile() {
        try {
            CRsystem crs = new CRsystem("Bank System: ");
            JsonWriter writer = new JsonWriter("./data/my\0illegal:fileName.json");
            writer.open();
            fail("IOException was expected");
        } catch (IOException e) {
            // pass
        }
    }

    @Test
    void testWriterEmptyWorkroom() {
        try {
            CRsystem crs = new CRsystem("Bank System: ");
            JsonWriter writer = new JsonWriter("./data/testWriterEmptyCRsystem.json");
            writer.open();
            writer.write(crs);
            writer.close();

            JsonReader reader = new JsonReader("./data/testWriterEmptyCRsystem.json");
            crs = reader.read();
            assertEquals("Bank System: ", crs.getSystemName());
            assertEquals(0, crs.getCusTomers().size());
            assertEquals(0, crs.getLowriskCustomers().size());
        } catch (IOException e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    void testWriterGeneralWorkroom() {
        try {
            CRsystem crs = new CRsystem("Bank System: ");
            Client client1 = new Client("a", 10101010, 100, 800, 1);
            Client client2 = new Client("b", 11111111, 100, 500, 1);
            crs.addClient(client1);
            crs.addClient(client2);
            JsonWriter writer = new JsonWriter("./data/testWriterGeneralCRsystem.json");
            writer.open();
            writer.write(crs);
            writer.close();

            JsonReader reader = new JsonReader("./data/testWriterGeneralCRsystem.json");
            crs = reader.read();
            assertEquals("Bank System: ", crs.getSystemName());
            ArrayList<Client> customers = crs.getCusTomers();
            assertEquals(2, customers.size());
            checkCRsystem("a", 10101010, 100, 800, 1, customers.get(0));
            checkCRsystem("b", 11111111, 100, 500, 1, customers.get(1));

            ArrayList<Client> lowriskcustomers = crs.getLowriskCustomers();
            assertEquals(1, lowriskcustomers.size());
            checkCRsystemLow("a", 10101010, 100, 800, 1, lowriskcustomers.get(0));

        } catch (IOException e) {
            fail("Exception should not have been thrown");
        }
    }
}
