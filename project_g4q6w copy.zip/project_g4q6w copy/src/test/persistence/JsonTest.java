package persistence;


import model.Client;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class JsonTest {

    protected void checkCRsystem(String n, int id, int loan, int score, int pi, Client client) {
        assertEquals(n, client.getName());
        assertEquals(id, client.getId());
        assertEquals(loan, client.getLoan());
        assertEquals(score, client.getCrscore());
        assertEquals(pi, client.getPi());
    }

    protected void checkCRsystemLow(String n, int id, double loan, int score, int pi, Client client) {
        assertEquals(n, client.getName());
        assertEquals(id, client.getId());
        assertEquals(loan, client.getLoan());
        assertEquals(score, client.getCrscore());
        assertEquals(pi, client.getPi());
    }
}
