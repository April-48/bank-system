package model;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
public class TestCRsystem {
    private CRsystem testsystem1;
    private CRsystem testsystem2;
    private CRsystem testsystem3;
    private Client client1 = new Client("a", 10101010, 100,500, 1);
    private Client client2 = new Client("b", 10101011, 200,100, 1);
    private Client client3 = new Client("c", 10101012, 100,700, 1);
    private Client client4 = new Client("d", 10101013, 100,700, 0);
    private Client client5 = new Client("3", 10101014, 100,700, 0);

    @BeforeEach
    public void runbefore() {
        testsystem1 = new CRsystem("Bank System: ");
        testsystem2 = new CRsystem("Bank System: ");
        testsystem3 = new CRsystem("Bank System: ");
    }

    @Test
    void testConstructor() {
        assertEquals("Bank System: ", testsystem1.getSystemName());
        assertEquals(0, testsystem1.getCusTomers().size());
//        assertEquals(500.0, testAccount.getBalance());
//        assertTrue(testAccount.getId() > 0);
    }

    @Test
    void testaddClient() {
        testsystem1.addClient(client1);
        assertEquals(1, testsystem1.getCusTomers().size());
        testsystem1.addClient(client2);
        assertEquals(2, testsystem1.getCusTomers().size());
    }

    @Test
    void testtotalprofit() {
        testsystem1.addClient(client1);
        testsystem1.addClient(client2);
        assertEquals(15, testsystem1.totalProfit(testsystem1.getCusTomers()));
 //       assertEquals(300, CRsystem.sumloan);
        testsystem3.addClient(client1);
        testsystem3.addClient(client2);
        testsystem3.addClient(client4);
        assertEquals(-85, testsystem3.totalProfit(testsystem3.getCusTomers()));

        testsystem2.addClient(client4);
        testsystem2.addClient(client5);
        assertEquals(-200, testsystem2.totalProfit(testsystem2.getCusTomers()));
    }


    @Test
    void testhighriskcustomers() {
        testsystem2.addClient(client1);
        testsystem2.addClient(client2);
        testsystem2.addClient(client3);
        assertEquals(2, testsystem2.highRiskCustomers(testsystem2.getCusTomers()).size());
    }

    @Test
    void testremovecustomers() {
        testsystem2.addClient(client1);
        testsystem2.addClient(client2);
        testsystem2.addClient(client3);
        testsystem2.removeCustomers();
        assertEquals(1, testsystem2.getLowriskCustomers().size());


    }
}
