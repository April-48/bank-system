package model;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


class TestClient {
    private Client testclient1;
    private Client testclient2;
    private Client testclient3;
    private static int loanRequest1 = 100;


    private int performanceIndicator;
    private String clientName;
    private int clientID;
    private int loanRequest;
    private int creditRiskScore;

    @BeforeEach
    public void runbefore() {
        testclient1 = new Client(clientName, clientID, loanRequest, creditRiskScore, performanceIndicator);
        testclient2 = new Client(clientName, clientID, loanRequest, creditRiskScore, performanceIndicator);
        testclient3 = new Client(clientName, clientID, loanRequest, creditRiskScore, performanceIndicator);
    }

    @Test
    void TestConstructor(){
        assertNull(testclient1.getName());
        assertEquals(0, testclient1.getId());
        assertEquals(0, testclient1.getLoan());
        assertEquals(0, testclient1.getCrscore());
        assertEquals(0, testclient1.getPi());

         //assertTrue((testclient1.getName()).length() > 0);
        //       assertEquals(8, String.valueOf(testclient1.getId()).length());
        //       assertTrue(testclient1.getId() > 0);
        //       assertTrue((testclient1.getloan()) > 0);
        //       assertTrue(testclient1.getpi() == 0 || testclient1.getpi() == 1);
    }

    @Test
    void Testuniquename(){
        testclient1.uniqueName("a");
        assertEquals("a", testclient1.getName());
        assertTrue(String.valueOf(testclient1.getName()).length() > 0);
    }

    @Test
    void TestuniqueID(){
        testclient1.uniqueID(10101010);
        assertEquals(10101010, testclient1.getId());
        assertTrue(String.valueOf(testclient1.getId()).length() == 8);
    }


    @Test
    void Testuniqueloan(){
        testclient1.uniqueLoan(loanRequest1);
        assertEquals(loanRequest1, testclient1.getLoan());
        assertTrue(testclient1.getLoan() > 0);
        testclient2.uniqueLoan(-100);
        assertEquals(0, testclient2.getLoan());
        assertTrue(testclient2.getLoan()  == 0);
        testclient3.uniqueLoan(0);
        assertEquals(0, testclient3.getLoan());
        assertTrue(testclient3.getLoan()  == 0);

    }


    @Test
    void Testuniquescore(){
        testclient1.uniqueCrscore(355);
        assertEquals(355, testclient1.getCrscore());
        assertTrue(testclient1.getCrscore() >= 0);
        testclient2.uniqueCrscore(0);
        assertEquals(0, testclient2.getCrscore());
        assertTrue(testclient2.getCrscore() >= 0);
        testclient3.uniqueCrscore(-10);
        assertEquals(0, testclient3.getCrscore());
        assertTrue(testclient3.getCrscore() == 0);
    }

    @Test
    void Testuniquepi(){
        testclient1.uniquePi(1);
        assertEquals(1, testclient1.getPi());
        assertTrue(testclient1.getPi() == 1 || testclient1.getPi() == 0);
        testclient2.uniquePi(0);
        assertEquals(0, testclient2.getPi());
        assertTrue(testclient2.getPi() == 1 || testclient2.getPi() == 0);
        testclient3.uniquePi(3);
        assertEquals(0, testclient3.getPi());
        assertTrue(testclient3.getPi() == 0);
    }


}