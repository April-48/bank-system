# Cpsc 210 Project: Risk Management of Banking

## Proposal of This project

The application designed in this project is about
a  bank's risk management system. It allows you to
enter information about each client, which include clients'
name, unique client ID, the amount of loan request,
their personal credit risk score and their performance
indicator to analyse risks undertaken by the bank.


***Banks** can use this application to*:
- analysing undertaken risks（whether Banks will profit from it）
- know clients' information

I am interested in this project is because I'm curious
as to why banks can't make a profit when they loan money 
to clients at very *high* loan interest.




## User Stories
*How someone can use your application 
to produce a specific outcome*:
- As a user, I want to be able to add a new client to 
my risk management system
- As a user, I want to be able to view the list of clients
recorded in my system
- As a user, I want to be able to mark a client in the system 
as someone with low credit risk score 
- As a user, I want to be able to remove a client from
my risk management system
- As a user, when I select the quit option from the application menu, 
I want to be reminded to save the client list to file and have the option to do so or not. 
- As a user, when I start the application, I want to be given the option to load my recorded client list from file.



## Phase 4: Task 2
Fri Dec 02 22:12:14 PST 2022
Added client: model.Client@12dffcc2
Client: a 12231232 100.0 100 1

Fri Dec 02 22:12:24 PST 2022
Added client: model.Client@75627c5
Client: b 12231233 100.0 500 1

Fri Dec 02 22:12:36 PST 2022
Added client: model.Client@77f7d7a3
Client: c 12231230 100.0 600 1

Fri Dec 02 22:12:39 PST 2022
Remove clients: model.Client@12dffcc2
Client: a 12231232 100.0 100 1

Fri Dec 02 22:12:39 PST 2022
Remove clients: model.Client@75627c5
Client: b 12231233 100.0 500 1

Fri Dec 02 22:12:42 PST 2022
Mark clients: model.Client@12dffcc2
Client: a 12231232 100.0 100 1

Fri Dec 02 22:12:42 PST 2022
Mark clients: model.Client@75627c5
Client: b 12231233 100.0 500 1

Fri Dec 02 22:12:44 PST 2022
Get Total Profit: $15.0



## Phase 4: Task 3
*If you had more time to work on the project, 
is there any refactoring that you would do to improve your design*？
- I would add a helper funtion(method) for setting the JFrame to reduce the 
number of duplicate lines about adding and setting different JButtons and JLabels.
- I would overload the methods used to close JDialog.  
Methods have different number of perameters which are JDialogs needed to be closed.
- Since every event needs a new window to show output and a button to close window, 
I would add a abstract class, which include setting JDialog and adding a *close* 
JButton, to reduce duplication.

